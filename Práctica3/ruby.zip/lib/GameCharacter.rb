#encoding: utf-8

# Enumerado que representa los personajes del juego

module Deepspace
    module GameCharacter
        ENEMYSTARSHIP= :enemystarship 
        SPACESTATION= :spacestation 
    end
end

# Código de comprobación
# puts Deepspace::GameCharacter::SPACESTATION